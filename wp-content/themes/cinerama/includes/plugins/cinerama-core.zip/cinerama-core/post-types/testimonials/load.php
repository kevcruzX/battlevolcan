<?php

include_once CINERAMA_CORE_CPT_PATH . '/testimonials/testimonials-register.php';
include_once CINERAMA_CORE_CPT_PATH . '/testimonials/helper-functions.php';