<?php

include_once CINERAMA_CORE_SHORTCODES_PATH . '/icon/functions.php';
include_once CINERAMA_CORE_SHORTCODES_PATH . '/icon/icon.php';