<?php

include_once CINERAMA_CORE_SHORTCODES_PATH . '/lightbox-image-carousel/functions.php';
include_once CINERAMA_CORE_SHORTCODES_PATH . '/lightbox-image-carousel/lightbox-image-carousel.php';