<?php

include_once CINERAMA_TWITTER_SHORTCODES_PATH . '/twitter-list/functions.php';
include_once CINERAMA_TWITTER_SHORTCODES_PATH . '/twitter-list/twitter-list.php';